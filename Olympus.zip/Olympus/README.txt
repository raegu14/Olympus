Olympus:
	Burning things. Fire just wants to survive.

Run Directions:
	Download and unzip file. Run executable.

Release Notes:
	Final version.
	Contains levels 1-3 and boss fight with all mechanics implemented.
		1. Movement
		2. Burning by touching
		3. Camera Zoom
		4. Checkpoint levels
		5. Rain
		6. Puddles


Attributions:
"Earth Prelude" "Devastation and Revenge" "Consequence" "Dama-May" "Thunderbird" by Kevin MacLeod (incompetech.com)
"Wood_Creak_02" by dheming (freesound.org)
"Flame Ignition" by Hykenfreak (freesound.org)
"Footsteps_Water_Light_008" "Footsteps_Water_Light_005" by duckduckpony (freesound.org)
"Puddle2" by acclivity (freesound.org)
�Cigarette_Lighter_Sparking� by vcspran (freesound.org)

Font: �Journey PS3� by Hauke Peterson (dafont.com)

Licensed under Creative Commons: By Attribution 3.0 License
http://creativecommons.org/licenses/by/3.0/

